-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table siswa_db.guru
CREATE TABLE IF NOT EXISTS `guru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `alamat` text,
  `nomor_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `bidang_pengajaran` varchar(255) DEFAULT NULL,
  `pendidikan_terakhir` varchar(255) DEFAULT NULL,
  `pengalaman_kerja` text,
  `gambar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table siswa_db.guru: ~1 rows (approximately)
/*!40000 ALTER TABLE `guru` DISABLE KEYS */;
INSERT INTO `guru` (`id`, `nama`, `nip`, `alamat`, `nomor_telepon`, `email`, `tanggal_lahir`, `jenis_kelamin`, `bidang_pengajaran`, `pendidikan_terakhir`, `pengalaman_kerja`, `gambar`) VALUES
	(2, 'Web Jasa', '987654321', 'Jl.Jambi Simpang III Sipin Kota Baru Kota Jambi', '65465464654', 'arieflukman557@gmail.com', '2023-12-13', 'Laki-laki', 'bidang', 'pendik', 'pengalaman', 'Icon_L_(set_orange).png');
/*!40000 ALTER TABLE `guru` ENABLE KEYS */;

-- Dumping structure for table siswa_db.siswa
CREATE TABLE IF NOT EXISTS `siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `umur` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `nomor_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `hobi` text,
  `kewarganegaraan` varchar(50) DEFAULT NULL,
  `agama` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table siswa_db.siswa: ~2 rows (approximately)
/*!40000 ALTER TABLE `siswa` DISABLE KEYS */;
INSERT INTO `siswa` (`id`, `nama`, `kelas`, `umur`, `gambar`, `alamat`, `nomor_telepon`, `email`, `tanggal_lahir`, `jenis_kelamin`, `hobi`, `kewarganegaraan`, `agama`) VALUES
	(3, 'Web Jasa', 'asd', 45, 'Screenshot (1).png', 'Jl.Jambi Simpang III Sipin Kota Baru Kota Jambi', '082180181958', 'arieflukman557@gmail.com', '2222-02-22', 'Laki-laki', 'asd', 'Indonesia', 'asdasdasd');
/*!40000 ALTER TABLE `siswa` ENABLE KEYS */;

-- Dumping structure for table siswa_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'siswa',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table siswa_db.users: ~1 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
	(1, 'admin', 'admin', 'admin');
INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
	(2, 'siswa', 'siswa', 'siswa');
INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
	(3, 'guru', 'guru', 'guru');
INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
	(5, 'pimpinan', 'pimpinan', 'pimpinan');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
